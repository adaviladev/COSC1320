// COSC 1320 Summer 2015
// Name: Adrian
// Homework 12
// This is my own work; I will not post
#include "Player.h"


Player::Player(void)
{
}


Player::~Player(void)
{
}
