// COSC 1320 Summer 2015
// Name: Adrian
// Homework 12
// This is my own work; I will not post
#pragma once
class Player{
public:
	Player(void);
	~Player(void);
	virtual int getGuess() = 0;
};

