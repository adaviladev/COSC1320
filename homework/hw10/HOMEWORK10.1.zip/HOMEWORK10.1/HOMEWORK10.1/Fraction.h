#pragma once

class Fraction{
	private:
		int numerator;
		int denominator;
		double value;

		int findCommonDivisor(int , int);
	public:
		void setNumerator(int);
		void setDenominator(int);
		double getAsDouble();
		void outputLowestTerms();
		Fraction(void);
		~Fraction(void);
};

