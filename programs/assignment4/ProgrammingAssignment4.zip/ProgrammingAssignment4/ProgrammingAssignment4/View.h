// COSC 1320 Summer 2015
// Name: Adrian
// Programming Assignment 4
// This is my own work; I will not post

#pragma once
#include <iostream>
using namespace std;
class View
{
public:
	View(void);
	~View(void);
	void showMenu();
};

