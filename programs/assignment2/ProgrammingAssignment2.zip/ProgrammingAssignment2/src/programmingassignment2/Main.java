// COSC 1320 Summer 2015
// Name: Adrian Davila
// Programming Assignment 2
// This is my own work; I will not post

package programmingassignment2;

public class Main{

    public static void main(String[] args) {
        // TODO code application logic here
        Controller controller = new Controller();

    }
}
